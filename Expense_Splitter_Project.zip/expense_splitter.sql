-- Created a table named users
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE
);

-- Creating a table named group_name
CREATE TABLE group_name (
    group_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100)
);

-- Creating a table for group members or users
CREATE TABLE group_members (
    group_id INT,
    user_id INT,
    PRIMARY KEY (group_id, user_id),
    FOREIGN KEY (group_id) REFERENCES group_name(group_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Creating a table for expense categories
CREATE TABLE expense_categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE
);

-- Creating a table named expenses to record payer, amount, date, description, and category
CREATE TABLE expenses (
    expense_id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT,
    payer_id INT,
    amount DECIMAL(10, 2),
    description VARCHAR(255),
    expense_date DATE,
    category_id INT,
    FOREIGN KEY (group_id) REFERENCES group_name(group_id),
    FOREIGN KEY (payer_id) REFERENCES users(user_id),
    FOREIGN KEY (category_id) REFERENCES expense_categories(category_id)
);

-- Creating a table named expense_splits to store how much each user owes per expense
CREATE TABLE expense_splits (
    expense_id INT,
    user_id INT,
    share_amount DECIMAL(10, 2),
    PRIMARY KEY (expense_id, user_id),
    FOREIGN KEY (expense_id) REFERENCES expenses(expense_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Creating a table named settlements to record payments between members
CREATE TABLE settlements (
    settlement_id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT,
    from_user INT,
    to_user INT,
    amount DECIMAL(10, 2),
    settlement_date DATE,
    FOREIGN KEY (group_id) REFERENCES group_name(group_id),
    FOREIGN KEY (from_user) REFERENCES users(user_id),
    FOREIGN KEY (to_user) REFERENCES users(user_id)
);

-- Inserting sample categories
INSERT INTO expense_categories (name) VALUES 
('Food'),
('Travel'),
('Utilities'),
('Entertainment'),
('Shopping');

-- Inserting sample users
INSERT INTO users (name, email) VALUES
('Amit', 'amit@example.com'),
('Neha', 'neha@example.com'),
('Rahul', 'rahul@example.com');

-- Creating a sample group
INSERT INTO group_name (name) VALUES ('Goa Trip');

-- Adding users to group (Group ID = 1)
INSERT INTO group_members (group_id, user_id) VALUES
(1, 1),  -- Amit
(1, 2),  -- Neha
(1, 3);  -- Rahul

-- Adding an expense: Amit paid ₹900 for dinner
INSERT INTO expenses (group_id, payer_id, amount, description, expense_date, category_id)
VALUES (1, 1, 900.00, 'Dinner at Hilton', '2025-06-20', 1);  -- 1 = Food

-- Splitting the ₹900 equally among 3 members
INSERT INTO expense_splits (expense_id, user_id, share_amount) VALUES
(1, 1, 300.00),  -- Amit
(1, 2, 300.00),  -- Neha
(1, 3, 300.00);  -- Rahul

-- Neha paid Amit ₹300 to settle her share
INSERT INTO settlements (group_id, from_user, to_user, amount, settlement_date)
VALUES (1, 2, 1, 300.00, '2025-06-21');

-- 
-- BALANCE CALCULATION QUERY
-- Shows how much each user owes or is owed (net)
-- 
SELECT 
    u.name,
    SUM(paid) - SUM(owed) AS balance
FROM (
    -- Total paid by user
    SELECT payer_id AS user_id, SUM(amount) AS paid, 0 AS owed
    FROM expenses GROUP BY payer_id

    UNION ALL

    -- Total owed by user
    SELECT user_id, 0 AS paid, SUM(share_amount) AS owed
    FROM expense_splits GROUP BY user_id
) AS balances
JOIN users u ON u.user_id = balances.user_id
GROUP BY u.name;

-- 
-- EXPENSE + SETTLEMENT HISTORY QUERY
-- Chronological log of all transactions in the group
-- 
SELECT 
    expense_date AS date,
    'Expense' AS type,
    description,
    payer_id AS from_user,
    NULL AS to_user,
    amount
FROM expenses

UNION ALL

SELECT 
    settlement_date AS date,
    'Settlement' AS type,
    NULL AS description,
    from_user,
    to_user,
    amount
FROM settlements

ORDER BY date;

-- Multiple Currency expense support

-- Creating a table currencies 
CREATE TABLE currencies (
    currency_code CHAR(3) PRIMARY KEY,   -- e.g., 'INR', 'USD'
    name VARCHAR(50)
);

-- Modifying expense table to store dollar value

ALTER TABLE expenses
ADD COLUMN currency_code CHAR(3),
ADD COLUMN conversion_rate DECIMAL(10, 4);  -- To convert to INR (or your base currency)

ALTER TABLE expenses
ADD FOREIGN KEY (currency_code) REFERENCES currencies(currency_code);


-- Insert currencies
INSERT INTO currencies (currency_code, name) VALUES
('INR', 'Indian Rupee'),
('USD', 'US Dollar');

-- Insert an expense in USD with conversion to INR
-- Let's say $100 and 1 USD = 83.50 INR
INSERT INTO expenses (group_id, payer_id, amount, description, expense_date, category_id, currency_code, conversion_rate)
VALUES (1, 1, 100.00, 'Hotel booking in USD', '2025-06-21', 2, 'USD', 83.50);
