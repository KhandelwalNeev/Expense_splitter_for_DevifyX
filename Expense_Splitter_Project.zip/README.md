
# 💸 Expense Splitter for Groups – MySQL Project

## 📌 Objective
Build a SQL-only solution to manage shared group expenses, track balances, handle settlements, and support multi-currency transactions.

This system is built entirely in **MySQL** with no frontend/backend. All logic is implemented via tables, foreign keys, queries, and constraints.

---

## 📁 Database Schema Overview

### 1. `users`
Stores user information.

| Column     | Type         | Description               |
|------------|--------------|---------------------------|
| user_id    | INT          | Primary key               |
| name       | VARCHAR(100) | User name                 |
| email      | VARCHAR(100) | Unique email              |

---

### 2. `group_name`
Stores group details.

| Column     | Type         | Description               |
|------------|--------------|---------------------------|
| group_id   | INT          | Primary key               |
| name       | VARCHAR(100) | Group name                |

---

### 3. `group_members`
Links users to groups (many-to-many).

| Column     | Type | Description                        |
|------------|------|------------------------------------|
| group_id   | INT  | Foreign key to `group_name`        |
| user_id    | INT  | Foreign key to `users`             |

---

### 4. `expense_categories`
Stores expense types (Food, Travel, etc.).

| Column        | Type         | Description         |
|---------------|--------------|---------------------|
| category_id   | INT          | Primary key         |
| name          | VARCHAR(50)  | Unique category     |

---

### 5. `expenses`
Main table for recording expenses.

| Column          | Type           | Description                                |
|-----------------|----------------|--------------------------------------------|
| expense_id      | INT            | Primary key                                |
| group_id        | INT            | Foreign key to `group_name`                |
| payer_id        | INT            | Who paid the amount                        |
| amount          | DECIMAL(10,2)  | Original amount                            |
| description     | VARCHAR(255)   | Expense note                               |
| expense_date    | DATE           | Date of the expense                        |
| category_id     | INT            | Linked to `expense_categories`            |
| currency_code   | CHAR(3)        | Currency used (e.g., INR, USD)             |
| conversion_rate | DECIMAL(10,4)  | Conversion rate to base currency (INR)     |

---

### 6. `expense_splits`
Defines how much each user owes per expense.

| Column      | Type           | Description                           |
|-------------|----------------|---------------------------------------|
| expense_id  | INT            | Foreign key to `expenses`             |
| user_id     | INT            | Foreign key to `users`                |
| share_amount| DECIMAL(10,2)  | How much this user owes for expense   |

---

### 7. `settlements`
Records actual money transfers between users.

| Column         | Type           | Description                        |
|----------------|----------------|------------------------------------|
| settlement_id  | INT            | Primary key                        |
| group_id       | INT            | Foreign key to `group_name`        |
| from_user      | INT            | Who paid                            |
| to_user        | INT            | Who received                        |
| amount         | DECIMAL(10,2)  | Settlement amount                  |
| settlement_date| DATE           | When settlement was made           |

---

### 8. `currencies`
Stores supported currency codes.

| Column        | Type      | Description       |
|---------------|-----------|-------------------|
| currency_code | CHAR(3)   | e.g. 'INR', 'USD' |
| name          | VARCHAR   | Full name         |

---

## 🧪 Sample Data Included

- 3 Users: Amit, Neha, Rahul
- 1 Group: Goa Trip
- Expense: Dinner worth ₹900 by Amit
- Equal split: ₹300 each
- Neha paid ₹300 to Amit as settlement
- One multi-currency expense added (USD with conversion)

---

## 💰 Key Queries

### 🔸 Balance Calculation
Shows how much each user owes or is owed.

```sql
SELECT 
    u.name,
    SUM(paid) - SUM(owed) AS balance
FROM (
    SELECT payer_id AS user_id, SUM(amount * conversion_rate) AS paid, 0 AS owed
    FROM expenses GROUP BY payer_id

    UNION ALL

    SELECT user_id, 0 AS paid, SUM(share_amount * e.conversion_rate) AS owed
    FROM expense_splits es
    JOIN expenses e ON es.expense_id = e.expense_id
    GROUP BY user_id
) AS balances
JOIN users u ON u.user_id = balances.user_id
GROUP BY u.name;
```

---

### 🔸 Expense + Settlement History

```sql
SELECT 
    expense_date AS date,
    'Expense' AS type,
    description,
    payer_id AS from_user,
    NULL AS to_user,
    amount * conversion_rate AS converted_amount
FROM expenses

UNION ALL

SELECT 
    settlement_date AS date,
    'Settlement' AS type,
    NULL AS description,
    from_user,
    to_user,
    amount
FROM settlements

ORDER BY date;
```

---

## Bonus Features Implemented

- Custom expense categories
- Multi-currency support
- Balance calculation
- Expense history log
- Clean and normalized schema

---


## Author

This project was created as part of the DevifyX SQL Assignment – *Expense Splitter for Groups*.
